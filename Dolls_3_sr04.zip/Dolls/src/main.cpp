#include "functions.h"
#include "start_inits.h"

//======================================================================================================
//------------------------------------------------------------------------------------------------------
//                                        SETUP
//------------------------------------------------------------------------------------------------------
void setup(void)
{
    //------------------------------------------------------ GAME INITS
    hardware_init();
    
	//------------------------------------------------------ GAME INITS
    start_variables_init();

	delay(1000);

}//setup()
//------------------------------------------------------------------------------------------------------
//                                        LOOP
//------------------------------------------------------------------------------------------------------
void loop(void)
{	
	//------------------------------------------- ALGORITHM >>>
	//STATE MACHINE
    switch(current_state)
    {
        case CALCULATE_STATE:
			current_min_distance_index = getMinDistanceIndex(distance_array);
			current_angle = getCurrentTargetAngle(current_min_distance_index);
			calculateDollsAngles(current_angle, distance_array[current_min_distance_index]);
			rotateDolls();

			current_state = FIRST_SECTOR_STATE;
            break;

		case MAIN_WORK_STATE:
			// calculate new angles
 			getSonarData(distance_array);
			current_min_distance_index = getMinDistanceIndex(distance_array);
			current_angle = getCurrentTargetAngle(current_min_distance_index);
			calculateDollsAngles(current_angle, distance_array[current_min_distance_index]);
			rotateDolls();

			break;

        default:
            break;
    }//[switch] STATE MACHINE
  //------------------------------------------- <<< ALGORITHM


  //------------------------------------------------------------------------------------

    //---DBG info
    // #ifdef DBG
    // if(millis() - DBG_time_delay >= DBG_out_interval)
    // {
    //     DBG_time_delay = millis();
        
    //     // printDBG("");
    // }
    // #endif
  
}//loop()