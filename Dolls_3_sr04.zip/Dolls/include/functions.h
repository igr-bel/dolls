#ifndef FUNCTIONS_INCLUDED
#define FUNCTIONS_INCLUDED

#include <Arduino.h>

#include <NewPing.h>

#include "main.h"
#include <VarSpeedServo.h>

//------------------------------------------------------------------------------------------------------
//                                        DEFINES
//------------------------------------------------------------------------------------------------------
#define DBG

#ifdef DBG
  unsigned long DBG_out_interval = 100;
  unsigned long DBG_time_delay = 0;
  #define printDBG(str)     Serial.print("[DBG] "); Serial.println(str) 
#else 
  #define printDBG(str)     ;
#endif

#define NOP                             do{}while(0)

//GPIO
#define concat(a,b)						a ## b

#define DOLL_PIN_C						23
#define DOLL_PIN_L						25
#define DOLL_PIN_R						27

#define SERVO_SPEED						30

#define PIN_TRIG_C						20
#define PIN_ECHO_C						21
#define PIN_TRIG_L						13
#define PIN_ECHO_L						12
#define PIN_TRIG_R						11
#define PIN_ECHO_R						10

#define MAX_DISTANCE					200
#define MIN_DISTANCE					50
#define DISTANCE_TRESHOLD				30

#define NUM_OF_SECTORS					30
#define NUM_OF_MEASUERMENTS				NUM_OF_SECTORS+1


//------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------
//                                        OBJECTS
//------------------------------------------------------------------------------------------------------
NewPing sonar_c(PIN_TRIG_C, PIN_ECHO_C, MAX_DISTANCE);
NewPing sonar_l(PIN_TRIG_L, PIN_ECHO_L, MAX_DISTANCE);
NewPing sonar_r(PIN_TRIG_R, PIN_ECHO_R, MAX_DISTANCE);

VarSpeedServo doll_center;
VarSpeedServo doll_left;
VarSpeedServo doll_right;

//------------------------------------------------------------------------------------------------------
//                                        GLOBAL VARIABLES
//------------------------------------------------------------------------------------------------------
//loads

//game
enum
{
    EN = 1,
    FR
};

enum
{
    CLOSED,
    OPEN
};

enum
{
    OFF,
    ON,
    PULSE
};

enum
{
    OK,
    ERR
};


// stepper
float steppers_angles[NUM_OF_MEASUERMENTS] = {20.0, 5.0, 10.0, 15.0, 20.0, 25.0, 
											30.0, 35.0, 40.0, 45.0, 50.0, 55.0, 
											60.0, 65.0, 70.0, 75.0, 80.0, 85.0, 
											90.0, 95.0, 100.0, 105.0, 110.0, 115.0, 
											120.0, 125.0, 130.0, 135.0, 140.0, 145.0, 130.0};

// sonars
uint16_t distance_array[NUM_OF_MEASUERMENTS];

//
uint8_t current_min_distance_index;

const uint16_t doll_left_distance = 20;
const uint16_t doll_right_distance = 20;

const float angle_offset = 0;
const float doll_center_offset = 0;
const float doll_left_offset = 0;
const float doll_right_offset = 0;
float current_angle;
float doll_center_angle;
float doll_left_angle;
float doll_right_angle;

//
const uint8_t left_sector_index = 0;
const uint8_t left_median_index = 7;
const uint8_t center_sector_index = 15;
const uint8_t right_median_index = 22;
const uint8_t right_sector_index = 30;

//------------------------------------------------------------------------------------------------------
//                                        FLAGS
//------------------------------------------------------------------------------------------------------


//------------------------------------------------------------------------------------------------------
//                                        PROTOTYPES
//------------------------------------------------------------------------------------------------------
//RESET
void(* resetFunc) (void) = 0;

//HARDWARE
inline void hardware_init(void);

//MAIN WORK
void getSonarData(uint16_t *dist_array);
uint8_t getMinDistanceIndex(uint16_t *dist_array);
float getCurrentTargetAngle(uint8_t min_distance_index);
void calculateDollsAngles(float current_stepper_angle, uint16_t current_distance);
void rotateDolls(void);

//------------------------------------------------------------------------------------------------------
//                                       BEHAVIOR
//------------------------------------------------------------------------------------------------------
inline void hardware_init(void)
{
    #ifdef DBG
        Serial.begin(9600);
		Serial.println("---------------------");
        Serial.println("     ___DBG___");
		Serial.println("---------------------");
        Serial.println("[DBG] start init ... ");
    #endif

    //------------------------------------------------------ GPIO
	doll_center.attach(DOLL_PIN_C);
	doll_left.attach(DOLL_PIN_L);
	doll_right.attach(DOLL_PIN_R);

    printDBG("[DBG] done!");
}//hardware_init()
//------------------------------------------------------------------------------------------------------
uint8_t getMinDistanceIndex(uint16_t *dist_array)
{
	uint8_t _index_of_minimum;
	uint8_t _neighbor_index;
	static uint8_t _prew_index_of_minimum;
	bool _person_not_found;

	_index_of_minimum = (dist_array[left_sector_index] < dist_array[center_sector_index]) ? left_sector_index : center_sector_index;
	_index_of_minimum = (dist_array[right_sector_index] < dist_array[_index_of_minimum]) ? right_sector_index : _index_of_minimum;

	switch (_index_of_minimum)
	{
		case left_sector_index:
			if(abs(dist_array[left_sector_index] - dist_array[center_sector_index]) < DISTANCE_TRESHOLD)
			{
				_index_of_minimum = left_median_index;
			}
			break;

		case center_sector_index:
			_neighbor_index = (dist_array[left_sector_index] < dist_array[right_sector_index]) ? left_sector_index : right_sector_index;
			
			if(abs(dist_array[_neighbor_index] - dist_array[center_sector_index]) < DISTANCE_TRESHOLD)
			{
				_index_of_minimum = (_neighbor_index + center_sector_index) / 2;
			}
			break;	
		
		case right_sector_index:
			if(abs(dist_array[right_sector_index] - dist_array[center_sector_index]) < DISTANCE_TRESHOLD)
			{
				_index_of_minimum = right_median_index;
			}
			break;

		default:
			break;
	}//switch

	_person_not_found = true;
	for(uint8_t i = 0; i < NUM_OF_MEASUERMENTS; i++)
	{
		if(dist_array[i] != MAX_DISTANCE)
		{
			_person_not_found = false;
		}
	}

	if(_person_not_found)
	{
		_index_of_minimum = _prew_index_of_minimum;	//return prew value
	}

	_prew_index_of_minimum = _index_of_minimum;
	
	return _index_of_minimum;
}
//------------------------------------------------------------------------------------------------------
float getCurrentTargetAngle(uint8_t min_distance_index)
{
	return steppers_angles[min_distance_index];
}//getCurrentStepperAngle()
//------------------------------------------------------------------------------------------------------
void calculateDollsAngles(float current_stepper_angle, uint16_t current_distance)
{
	// doll center
	doll_center_angle = current_stepper_angle;

	//doll right
	current_stepper_angle = 150.0 - current_stepper_angle;
	doll_right_angle = degrees(
						acos( 
								((float)doll_right_distance - (float)current_distance * cos(radians(current_stepper_angle))) / 
								sqrtf( sq((float)current_distance) + sq((float)doll_right_distance) - 2.0 * (float)current_distance * (float)doll_right_distance * cos(radians(current_stepper_angle)) ) 
							)
						);

	if(doll_right_angle < 90)
	{
		doll_right_angle = 90;
	}

	// doll left
	doll_left_angle = degrees(
						acos( 
								((float)doll_left_distance - (float)current_distance * cos(radians(current_stepper_angle))) / 
								sqrtf( sq((float)current_distance) + sq((float)doll_left_distance) - 2.0 * (float)current_distance * (float)doll_left_distance * cos(radians(current_stepper_angle)) ) 
							)
						);

	if(doll_left_angle > 110)
	{
		doll_left_angle = 110;
	}

	return;
}//calculateDollsAngles()
//------------------------------------------------------------------------------------------------------
void rotateDolls(void)
{
	doll_center.slowmove ((uint8_t)round(doll_center_angle), SERVO_SPEED);
	doll_left.slowmove ((uint8_t)round(doll_left_angle), SERVO_SPEED);
	doll_right.slowmove ((uint8_t)round(doll_right_angle), SERVO_SPEED);

	return;
}//rotateDolls()
//------------------------------------------------------------------------------------------------------
void getSonarData(uint16_t *dist_array)
{
	uint32_t _time_l;
	uint32_t _time_c;
	uint32_t _time_r;

	_time_l = sonar_l.ping_median(3, MAX_DISTANCE);
	dist_array[left_sector_index] = sonar_l.convert_cm(_time_l);
	delay(20);
	_time_c = sonar_c.ping_median(3, MAX_DISTANCE);
	dist_array[center_sector_index] = sonar_c.convert_cm(_time_c);
	delay(20);
	_time_r = sonar_r.ping_median(3, MAX_DISTANCE);
	dist_array[right_sector_index] = sonar_r.convert_cm(_time_r);
	delay(20);

	Serial.print(dist_array[left_sector_index]);
	Serial.print("  <  ");
	Serial.print(dist_array[center_sector_index]);
	Serial.print("  >  ");
	Serial.println(dist_array[right_sector_index]);


	// drop small or error measurments
	if(dist_array[left_sector_index] < MIN_DISTANCE)
	{
		dist_array[left_sector_index] = MAX_DISTANCE;				
	}

	if(dist_array[center_sector_index] < MIN_DISTANCE)
	{
		dist_array[center_sector_index] = MAX_DISTANCE;				
	}

	if(dist_array[right_sector_index] < MIN_DISTANCE)
	{
		dist_array[right_sector_index] = MAX_DISTANCE;				
	}

	return;
}//getSonarData()
//------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------

#endif //FUNCTIONS_INCLUDED