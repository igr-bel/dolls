#include "functions.h"
#include "start_inits.h"

//======================================================================================================
//------------------------------------------------------------------------------------------------------
//                                        SETUP
//------------------------------------------------------------------------------------------------------
void setup(void)
{
    //------------------------------------------------------ GAME INITS
    hardware_init();
    
	//------------------------------------------------------ GAME INITS
    start_variables_init();

	//------------------------------------------------------ STEPPER
	stepperInit();
	checkStepperPosition();

	//------------------------------------------------------ TOF SENSOR
	vlxInit();
	delay(1000);

	//------------------------------------------------------ INTERRUPTS
	attachInterrupt(digitalPinToInterrupt(LIMIT_SWITCH_L_PIN), irqLimitSwitchL, RISING);
	// attachInterrupt(digitalPinToInterrupt(LIMIT_SWITCH_R_PIN), irqLimitSwitchR, RISING);

	current_state = FIRST_SECTOR_STATE;
}//setup()
//------------------------------------------------------------------------------------------------------
//                                        LOOP
//------------------------------------------------------------------------------------------------------
void loop(void)
{	
	//------------------------------------------- ALGORITHM >>>
	//STATE MACHINE
    switch(current_state)
    {
        case CALCULATE_STATE:
			current_min_distance_index = getMinDistanceIndex(distance_array, NUM_OF_MEASUERMENTS);
			current_angle = getCurrentStepperAngle(current_min_distance_index);
			calculateDollsAngles(current_angle, distance_array[current_min_distance_index]);
			rotateDolls();

			current_state = FIRST_SECTOR_STATE;
            break;

        case FIRST_SECTOR_STATE:
			if(stepper_direction == TO_LEFT)
			{
				sector_index = 0;
			}
			else
			{
				sector_index = NUM_OF_SECTORS;
			}

			vlx_distance = vlx.readRangeContinuousMillimeters();
			if(vlx_distance > 150 && vlx_distance < 2000)
			{
				distance_array[sector_index] = vlx_distance;
			}
			else
			{
				distance_array[sector_index] = 2000;
			}

			measured_sectors_counter = 1;

			first_sector_flag = false;
			current_state = MAIN_WORK_STATE;
            break;

		case MAIN_WORK_STATE:
			sector_index += stepper_direction;
			stepper.step(STEPS_PER_SECTOR * stepper_direction);

			vlx_distance = vlx.readRangeContinuousMillimeters();

			// calculate new angles
			current_min_distance_index = getMinDistanceIndex(distance_array, NUM_OF_MEASUERMENTS);
			current_angle = getCurrentStepperAngle(current_min_distance_index);
			calculateDollsAngles(current_angle, distance_array[current_min_distance_index]);
			rotateDolls();

			// drop small or error measurments
			if(vlx_distance > 150 && vlx_distance < 2000)
			{
				distance_array[sector_index] = vlx_distance;
			}
			else
			{
				distance_array[sector_index] = 2000;
			}

			// if(measured_sectors_counter < NUM_OF_MEASUERMENTS)
			// {
			// 	measured_sectors_counter++;
			// }

			if(sector_index == 0)
			{
				stepper_direction = TO_LEFT;
				first_sector_flag = true;
				current_state = CALCULATE_STATE;
			}

			break;

        default:
            break;
    }//[switch] STATE MACHINE
  //------------------------------------------- <<< ALGORITHM


  //------------------------------------------------------------------------------------

    //---DBG info
    // #ifdef DBG
    // if(millis() - DBG_time_delay >= DBG_out_interval)
    // {
    //     DBG_time_delay = millis();
        
    //     // printDBG("");
    // }
    // #endif
  
}//loop()