#ifndef FUNCTIONS_INCLUDED
#define FUNCTIONS_INCLUDED

#include <Arduino.h>

#include <Stepper.h>

// #include <Wire.h>
// #include <VL53L0X.h>

#include <NewPing.h>

#include "main.h"
#include <VarSpeedServo.h>

//------------------------------------------------------------------------------------------------------
//                                        DEFINES
//------------------------------------------------------------------------------------------------------
// #define DBG

#ifdef DBG
  unsigned long DBG_out_interval = 100;
  unsigned long DBG_time_delay = 0;
  #define printDBG(str)     Serial.print("[DBG] "); Serial.println(str) 
#else 
  #define printDBG(str)     ;
#endif

#define NOP                             do{}while(0)

//GPIO
#define concat(a,b)						a ## b

#define DOLL_PIN_C						23
#define DOLL_PIN_L						25
#define DOLL_PIN_R						27

#define SERVO_SPEED						30

#define LIMIT_SWITCH_L_PIN				18
#define LIMIT_SWITCH_R_PIN				19

#define VLX_POWER_PIN					2

#define PIN_TRIG						20 //yellow wire
#define PIN_ECHO						21 //green wire

#define MAX_DISTANCE					200
#define MIN_DISTANCE					50
#define DISTANCE_TRESHOLD				10
	
//
#define TO_LEFT							1
#define TO_RIGHT						-1

#define NUM_OF_SECTORS					30
#define STEPS_PER_SECTOR				13	//25 steps for gear 1:1
#define NUM_OF_MEASUERMENTS				NUM_OF_SECTORS+1


//------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------
//                                        OBJECTS
//------------------------------------------------------------------------------------------------------
NewPing sonar(PIN_TRIG, PIN_ECHO, MAX_DISTANCE);

// VL53L0X vlx;

Stepper stepper = Stepper(200, 3, 7, 5, 9);

// Servo doll_center;
// Servo doll_left;
// Servo doll_right;

VarSpeedServo doll_center;
VarSpeedServo doll_left;
VarSpeedServo doll_right;

//------------------------------------------------------------------------------------------------------
//                                        GLOBAL VARIABLES
//------------------------------------------------------------------------------------------------------
//loads

//game
enum
{
    EN = 1,
    FR
};

enum
{
    CLOSED,
    OPEN
};

enum
{
    OFF,
    ON,
    PULSE
};

enum
{
    OK,
    ERR
};


// stepper
volatile int8_t stepper_direction;
int8_t stepper_prew_direction;
volatile uint32_t steps_counter;
float steppers_angles[NUM_OF_MEASUERMENTS] = {0.0, 5.0, 10.0, 15.0, 20.0, 25.0, 
											30.0, 35.0, 40.0, 45.0, 50.0, 55.0, 
											60.0, 65.0, 70.0, 75.0, 80.0, 85.0, 
											90.0, 95.0, 100.0, 105.0, 110.0, 115.0, 
											120.0, 125.0, 130.0, 135.0, 140.0, 145.0, 150.0};

// vlx
uint16_t vlx_distance;
uint16_t distance_array[NUM_OF_MEASUERMENTS];

//
uint8_t sector_index;
uint8_t measured_sectors_counter;
uint8_t current_min_distance_index;

const uint16_t doll_left_distance = 20;
const uint16_t doll_right_distance = 20;

const float angle_offset = 0; //21.88;
const float doll_center_offset = 0;
const float doll_left_offset = 0;
const float doll_right_offset = 0;
float current_angle;
float doll_center_angle;
float doll_left_angle;
float doll_right_angle;

//------------------------------------------------------------------------------------------------------
//                                        FLAGS
//------------------------------------------------------------------------------------------------------
bool first_sector_flag = false;

//------------------------------------------------------------------------------------------------------
//                                        PROTOTYPES
//------------------------------------------------------------------------------------------------------
//RESET
void(* resetFunc) (void) = 0;

//HARDWARE
inline void hardware_init(void);

//VLX
uint8_t vlxInit(void);
void irqLimitSwitchL(void);
void irqLimitSwitchR(void);

//STEPPER
void stepperInit(void);
void checkStepperPosition(void);

//MAIN WORK
uint8_t getMinDistanceIndex(uint16_t *dist_array, uint8_t measured_sector);
float getCurrentStepperAngle(uint8_t min_distance_index);
void calculateDollsAngles(float current_stepper_angle, uint16_t current_distance);
void rotateDolls(void);

//------------------------------------------------------------------------------------------------------
//                                       BEHAVIOR
//------------------------------------------------------------------------------------------------------
inline void hardware_init(void)
{
    #ifdef DBG
        Serial.begin(9600);
		Serial.println("---------------------");
        Serial.println("     ___DBG___");
		Serial.println("---------------------");
        Serial.println("[DBG] start init ... ");
    #endif

    //------------------------------------------------------ GPIO
	// VLX
	pinMode(VLX_POWER_PIN, OUTPUT);
	digitalWrite(VLX_POWER_PIN, LOW);
	delay(1000);
	digitalWrite(VLX_POWER_PIN, HIGH);
	delay(1000);

	// Wire.begin();

	doll_center.attach(DOLL_PIN_C);
	doll_left.attach(DOLL_PIN_L);
	doll_right.attach(DOLL_PIN_R);

    printDBG("[DBG] done!");
}//hardware_init()
//------------------------------------------------------------------------------------------------------
uint8_t getMinDistanceIndex(uint16_t *dist_array, uint8_t measured_sector)
{
	uint8_t _index_of_minimum;
	static uint8_t _prew_index_of_minimum;
	bool _person_not_found;

	_person_not_found = true;
	_index_of_minimum = 0;
	for(uint8_t i = 1; i < NUM_OF_MEASUERMENTS; i++)
	{
		if(i != measured_sector) //drop current measure -> it may be noise
		{
			if((dist_array[_index_of_minimum] - DISTANCE_TRESHOLD) > dist_array[i])
			{
				_index_of_minimum = i;
			}

			if(dist_array[i] != MAX_DISTANCE)
			{
				_person_not_found = false;
			}
		}
	}

	if(_person_not_found)
	{
		_index_of_minimum = _prew_index_of_minimum;	//return prew value
	}

	_prew_index_of_minimum = _index_of_minimum;
	
	return _index_of_minimum;
}
//------------------------------------------------------------------------------------------------------
float getCurrentStepperAngle(uint8_t min_distance_index)
{
	return steppers_angles[min_distance_index];
}//getCurrentStepperAngle()
//------------------------------------------------------------------------------------------------------
void calculateDollsAngles(float current_stepper_angle, uint16_t current_distance)
{
	// doll center
	doll_center_angle = current_stepper_angle;

	//doll right
	current_stepper_angle = 150.0 - current_stepper_angle;
	doll_right_angle = degrees(
						acos( 
								((float)doll_right_distance - (float)current_distance * cos(radians(current_stepper_angle))) / 
								sqrtf( sq((float)current_distance) + sq((float)doll_right_distance) - 2.0 * (float)current_distance * (float)doll_right_distance * cos(radians(current_stepper_angle)) ) 
							)
						);

	// doll left
	doll_left_angle = degrees(
						acos( 
								((float)doll_left_distance - (float)current_distance * cos(radians(current_stepper_angle))) / 
								sqrtf( sq((float)current_distance) + sq((float)doll_left_distance) - 2.0 * (float)current_distance * (float)doll_left_distance * cos(radians(current_stepper_angle)) ) 
							)
						);

	return;
}//calculateDollsAngles()
//------------------------------------------------------------------------------------------------------
void rotateDolls(void)
{
	doll_center.slowmove ((uint8_t)round(doll_center_angle), SERVO_SPEED);
	doll_left.slowmove ((uint8_t)round(doll_left_angle), SERVO_SPEED);
	doll_right.slowmove ((uint8_t)round(doll_right_angle), SERVO_SPEED);

	return;
}//rotateDolls()
//------------------------------------------------------------------------------------------------------
uint8_t vlxInit(void)
{
	// #define LONG_RANGE

	// #define HIGH_SPEED
	// // #define HIGH_ACCURACY

	// printDBG("vlx start init");
	// vlx.setTimeout(100);
	// while (!vlx.init())
	// {
	// 	Serial.println("TOF sensor not found!");
	// 	digitalWrite(VLX_POWER_PIN, LOW);
	// 	delay(1000);
	// 	digitalWrite(VLX_POWER_PIN, HIGH);
	// 	delay(1000);
	// 	printDBG("search vlx ...");
	// }

	// printDBG("vlx init signal");
	// #if defined LONG_RANGE
	// 	vlx.setSignalRateLimit(0.1);
	// 	vlx.setVcselPulsePeriod(VL53L0X::VcselPeriodPreRange, 18);
	// 	vlx.setVcselPulsePeriod(VL53L0X::VcselPeriodFinalRange, 14);
	// #endif

	// printDBG("vlx set mode");
	// #if defined HIGH_SPEED
	// 	// reduce timing to 20 ms (default 33 ms)
	// 	vlx.setMeasurementTimingBudget(20000);
	// #elif defined HIGH_ACCURACY
	// 	// increase timing to 200 ms
	// 	vlx.setMeasurementTimingBudget(200000);
	// #endif

	// printDBG("vlx init done!");

	// //start continuous measerement (as often as possible) 
	// // vlx.startContinuous();
	// printDBG("vlx start continuous measerement!");

	return 0;
}//vlxInit()
//------------------------------------------------------------------------------------------------------
void irqLimitSwitchL(void)
{
	stepper_direction = TO_RIGHT;
	first_sector_flag = true;
	// current_state = CALCULATE_STATE;
	current_state = FIRST_SECTOR_STATE;
}//irqLimitSwitch()
//------------------------------------------------------------------------------------------------------
void irqLimitSwitchR(void)
{
	stepper_direction = TO_LEFT;
	first_sector_flag = true;
	current_state = CALCULATE_STATE;
}//irqLimitSwitch()
//------------------------------------------------------------------------------------------------------
void stepperInit(void)
{
	stepper.setSpeed(165);
}//stepperInit()
//------------------------------------------------------------------------------------------------------
void checkStepperPosition(void)
{
	// if stepper stoped on limit swith sensor
	// move 100 steps to center and set clockwise direction

	pinMode(LIMIT_SWITCH_L_PIN, INPUT);
	pinMode(LIMIT_SWITCH_R_PIN, INPUT);

	if(digitalRead(LIMIT_SWITCH_L_PIN))
	{
		stepper.step(-100);
	}

	if(digitalRead(LIMIT_SWITCH_R_PIN))
	{
		stepper.step(100);
	}

	stepper_direction = TO_LEFT;

	return;
}//checkStepperPosition()
//------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------

#endif //FUNCTIONS_INCLUDED