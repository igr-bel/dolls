#include "functions.h"
#include "start_inits.h"

//======================================================================================================
//------------------------------------------------------------------------------------------------------
//                                        SETUP
//------------------------------------------------------------------------------------------------------
void setup(void)
{
    //------------------------------------------------------ GAME INITS
    hardware_init();
    
	//------------------------------------------------------ GAME INITS
    start_variables_init();

	//------------------------------------------------------ STEPPER
	stepperInit();
	checkStepperPosition();

	//------------------------------------------------------ TOF SENSOR
	// vlxInit();
	delay(1000);

	//------------------------------------------------------ INTERRUPTS
	attachInterrupt(digitalPinToInterrupt(LIMIT_SWITCH_L_PIN), irqLimitSwitchL, RISING);
	// attachInterrupt(digitalPinToInterrupt(LIMIT_SWITCH_R_PIN), irqLimitSwitchR, RISING);

	current_state = FIRST_SECTOR_STATE;
}//setup()
//------------------------------------------------------------------------------------------------------
//                                        LOOP
//------------------------------------------------------------------------------------------------------
void loop(void)
{	
	//------------------------------------------- ALGORITHM >>>
	//STATE MACHINE
    switch(current_state)
    {
        case CALCULATE_STATE:
			current_min_distance_index = getMinDistanceIndex(distance_array, NUM_OF_MEASUERMENTS);
			current_angle = getCurrentStepperAngle(current_min_distance_index);
			calculateDollsAngles(current_angle, distance_array[current_min_distance_index]);
			rotateDolls();

			current_state = FIRST_SECTOR_STATE;
            break;

        case FIRST_SECTOR_STATE:
			if(stepper_direction == TO_LEFT)
			{
				sector_index = 0;
			}
			else
			{
				sector_index = NUM_OF_SECTORS;
			}

			// vlx_distance = sonar.ping_cm(MAX_DISTANCE);

			// if(vlx_distance > MIN_DISTANCE && vlx_distance < MAX_DISTANCE)
			// {
			// 	distance_array[sector_index] = vlx_distance;
			// }
			// else
			// {
			// 	distance_array[sector_index] = MAX_DISTANCE;
			// }

			// first_sector_flag = false;
			current_state = MAIN_WORK_STATE;
            break;

		case MAIN_WORK_STATE:
			sector_index += stepper_direction;
			stepper.step(STEPS_PER_SECTOR * stepper_direction);

			if(sector_index > 2 && sector_index < 28)
			{
				vlx_distance = sonar.ping_cm(MAX_DISTANCE);

				// drop small or error measurments
				if(vlx_distance > MIN_DISTANCE && vlx_distance < MAX_DISTANCE)
				{
					distance_array[sector_index] = vlx_distance;				
				}
				else
				{
					distance_array[sector_index] = MAX_DISTANCE;

					if(distance_array[sector_index - 2*stepper_direction] == MAX_DISTANCE) //drop single noise
					{
						distance_array[sector_index - stepper_direction] = MAX_DISTANCE;
					}
				}

				// calculate new angles
				current_min_distance_index = getMinDistanceIndex(distance_array, sector_index);
				current_angle = getCurrentStepperAngle(current_min_distance_index);
				calculateDollsAngles(current_angle, distance_array[current_min_distance_index]);
				rotateDolls();
			}

			if(sector_index == 0)
			{
				stepper_direction = TO_LEFT;
				// first_sector_flag = true;
				// current_state = CALCULATE_STATE;
				current_state = FIRST_SECTOR_STATE;
			}

			break;

        default:
            break;
    }//[switch] STATE MACHINE
  //------------------------------------------- <<< ALGORITHM


  //------------------------------------------------------------------------------------

    //---DBG info
    // #ifdef DBG
    // if(millis() - DBG_time_delay >= DBG_out_interval)
    // {
    //     DBG_time_delay = millis();
        
    //     // printDBG("");
    // }
    // #endif
  
}//loop()